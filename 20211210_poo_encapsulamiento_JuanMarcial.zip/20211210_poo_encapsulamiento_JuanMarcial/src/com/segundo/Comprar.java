package com.segundo;

import com.primero.Coche;

public class Comprar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Coche coche1=new Coche(13562,"P12",1000.56f);
		Coche coche2=new Coche(25676,"A89",5678.98f);
		Coche coche3=new Coche(57842,"V90",3903.63f);
		Coche coche4=new Coche(52576,"W67",2543.65f);
		
		System.out.println(coche3.getPrecio());
		
	}

}
